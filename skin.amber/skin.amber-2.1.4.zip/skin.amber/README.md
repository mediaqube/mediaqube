skin.amber
==========

Amber skin for Kodi/XBMC
